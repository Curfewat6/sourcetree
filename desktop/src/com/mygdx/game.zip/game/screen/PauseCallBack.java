package com.mygdx.game.screen;

public interface PauseCallBack {
	
	public void togglePause();

}
