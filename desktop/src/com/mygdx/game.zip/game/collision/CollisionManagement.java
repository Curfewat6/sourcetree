package com.mygdx.game.collision;


public interface CollisionManagement {
	
	public int checkCollision();
	
}
