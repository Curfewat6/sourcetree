package com.mygdx.game.entity;

public interface Collision {
	
	boolean collideEntity(Entity tex);

}
