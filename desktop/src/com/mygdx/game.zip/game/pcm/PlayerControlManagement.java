package com.mygdx.game.pcm;

public interface PlayerControlManagement {

	void handlingPlayerInput();

	void setDirection(String dir);
	

}

